exports.HmrState = function() {
};
