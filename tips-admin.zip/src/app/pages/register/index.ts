export * from './register.component';
