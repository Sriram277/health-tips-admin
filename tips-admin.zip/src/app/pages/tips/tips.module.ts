import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule } from '@angular/forms';

import { routing }       from './tips.routing';
import { Tips } from './tips.component';
import { allTips } from './components/all-tips/all-tips.component';
import { addTips } from './components/add-tips/add-tips.component';
import { AllTipsService } from './components/all-tips/all-tips.service';
import { AddTipsService } from './components/add-tips/add-tips.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    routing,
  ],
  declarations: [
    Tips,
    addTips,
    allTips
  ],
  providers: [
    AllTipsService,
    AddTipsService
  ]
})
export class TipsModule {
}
