import {Component} from '@angular/core';

@Component({
  selector: 'tips',
  template: `<router-outlet></router-outlet>`
})
export class Tips {

  constructor() {
  }
}
