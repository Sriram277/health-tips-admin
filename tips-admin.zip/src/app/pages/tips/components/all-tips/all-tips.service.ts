import { Injectable } from '@angular/core';

@Injectable()
export class AllTipsService {

  editableTableData: Array<any>;


  constructor() {
    this.editableTableData = [];
  }
}
