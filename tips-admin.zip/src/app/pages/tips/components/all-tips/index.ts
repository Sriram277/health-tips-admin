export * from './all-tips.component';
