import {Component} from '@angular/core';

@Component({
  selector: 'all-tips',
  templateUrl: './all-tips.html'
})
export class allTips {

  constructor() {
  }
}
