import { Injectable } from '@angular/core';

@Injectable()
export class AddTipsService {

  editableTableData: Array<any>;


  constructor() {
    this.editableTableData = [];
  }
}
