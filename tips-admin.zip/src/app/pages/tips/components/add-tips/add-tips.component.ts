import {Component} from '@angular/core';

@Component({
  selector: 'add-tips',
  templateUrl: './add-tips.html'
})
export class addTips {

  constructor() {
  }
}
