import {Component} from '@angular/core';

import 'style-loader!./grid.scss';

@Component({
  selector: 'grid',
  templateUrl: './grid.html',
})
export class Grid {

  constructor() {
  }
}
