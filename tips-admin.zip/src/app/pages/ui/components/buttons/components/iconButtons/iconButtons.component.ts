import {Component} from '@angular/core';

@Component({
  selector: 'icon-buttons',
  templateUrl: './iconButtons.html',
})
export class IconButtons {

  constructor() {
  }
}
